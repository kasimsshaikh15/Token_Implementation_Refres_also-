package com.codewithdurgesh.blog.controllers;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordEncryptionExample {

	public static void main(String[] args) {

		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

		// The password you want to hash
		String rawPassword = "xyz";

		// Hash the password
		String hashedPassword = passwordEncoder.encode(rawPassword);

		// Output the hashed password
		System.out.println("Bcrypted Password: " + hashedPassword);

	}
}
