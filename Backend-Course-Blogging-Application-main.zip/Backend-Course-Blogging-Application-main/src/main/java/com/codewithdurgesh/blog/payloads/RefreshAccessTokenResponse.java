package com.codewithdurgesh.blog.payloads;

public class RefreshAccessTokenResponse {
	
//	 private String accessToken;
//
//	public String getAccessToken() {
//		return accessToken;
//	}
//
//	public void setAccessToken(String accessToken) {
//		this.accessToken = accessToken;
//	}
//
//	public RefreshAccessTokenResponse(String accessToken) {
//		super();
//		this.accessToken = accessToken;
//	}
//
//	public RefreshAccessTokenResponse() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//	 
//	 
//	 
	
	
	private String accessToken;
    private long expiresIn;
    private String tokenType;
    private String scope;
    private String refreshToken;
    private long refreshExpiresIn;
    private String mobileNumber;
    private String newAccount;
    
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public long getExpiresIn() {
		return expiresIn;
	}
	public void setExpiresIn(long expiresIn) {
		this.expiresIn = expiresIn;
	}
	public String getTokenType() {
		return tokenType;
	}
	public void setTokenType(String tokenType) {
		this.tokenType = tokenType;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	public String getRefreshToken() {
		return refreshToken;
	}
	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}
	public long getRefreshExpiresIn() {
		return refreshExpiresIn;
	}
	public void setRefreshExpiresIn(long refreshExpiresIn) {
		this.refreshExpiresIn = refreshExpiresIn;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getNewAccount() {
		return newAccount;
	}
	public void setNewAccount(String newAccount) {
		this.newAccount = newAccount;
	}
	public RefreshAccessTokenResponse(String accessToken, long expiresIn, String tokenType, String scope,
			String refreshToken, long refreshExpiresIn, String mobileNumber, String newAccount) {
		super();
		this.accessToken = accessToken;
		this.expiresIn = expiresIn;
		this.tokenType = tokenType;
		this.scope = scope;
		this.refreshToken = refreshToken;
		this.refreshExpiresIn = refreshExpiresIn;
		this.mobileNumber = mobileNumber;
		this.newAccount = newAccount;
	}
	public RefreshAccessTokenResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}
