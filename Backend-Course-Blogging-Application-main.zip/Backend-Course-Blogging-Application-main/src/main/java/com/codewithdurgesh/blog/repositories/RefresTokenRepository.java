//package com.codewithdurgesh.blog.repositories;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import com.codewithdurgesh.blog.entities.RefreshToken;
//
//public interface RefresTokenRepository extends JpaRepository<RefreshToken, String> {
//
//}
