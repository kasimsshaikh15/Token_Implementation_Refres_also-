package com.codewithdurgesh.blog.payloads;

public class LoginRequest {

	private String clientId;
	private String clientSecret;
	private String mobileNumber;
	private String wiFlow;
	private String grantType;


	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getWiFlow() {
		return wiFlow;
	}

	public void setWiFlow(String wiFlow) {
		this.wiFlow = wiFlow;
	}

	public String getGrantType() {
		return grantType;
	}

	public void setGrantType(String grantType) {
		this.grantType = grantType;
	}

	
}
