package com.codewithdurgesh.blog.payloads;

public class TokenResponse {
	
	
    private String token;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public TokenResponse(String token) {
		super();
		this.token = token;
	}

	public TokenResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

    

}
