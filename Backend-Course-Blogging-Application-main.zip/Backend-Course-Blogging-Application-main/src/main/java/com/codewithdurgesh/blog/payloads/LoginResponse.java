package com.codewithdurgesh.blog.payloads;

public class LoginResponse {
	
//    private String username;
//    private String token;
//	public String getUsername() {
//		return username;
//	}
//	public void setUsername(String username) {
//		this.username = username;
//	}
//	public String getToken() {
//		return token;
//	}
//	public void setToken(String token) {
//		this.token = token;
//	}
//	public LoginResponse(String username, String token) {
//		super();
//		this.username = username;
//		this.token = token;
//	}
//	public LoginResponse() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
	
	
	
	    private String access_token;
	    private long expires_in;
	    private String token_type;
	    private String scope;
	    private String refresh_token;
	    private long refresh_expires_in;
	    private String mobile_number;
	    private String new_account;
	    	    
		public LoginResponse() {
			super();
			// TODO Auto-generated constructor stub
		}

		public LoginResponse(String access_token, long expires_in, String token_type, String scoper,
				String refresh_token, long refresh_expires_in, String mobile_number, String new_account) {
			super();
			this.access_token = access_token;
			this.expires_in = expires_in;
			this.token_type = token_type;
			this.scope = scope;
			this.refresh_token = refresh_token;
			this.refresh_expires_in = refresh_expires_in;
			this.mobile_number = mobile_number;
			this.new_account = new_account;
		}
		
		
		public String getAccess_token() {
			return access_token;
		}
		public void setAccess_token(String access_token) {
			this.access_token = access_token;
		}
		public long getExpires_in() {
			return expires_in;
		}
		public void setExpires_in(long expires_in) {
			this.expires_in = expires_in;
		}
		public String getToken_type() {
			return token_type;
		}
		public void setToken_type(String token_type) {
			this.token_type = token_type;
		}
		public String getScope() {
			return scope;
		}
		public void setScope(String scope) {
			this.scope = scope;
		}
		public String getRefresh_token() {
			return refresh_token;
		}
		public void setRefresh_token(String refresh_token) {
			this.refresh_token = refresh_token;
		}
		public long getRefresh_expires_in() {
			return refresh_expires_in;
		}
		public void setRefresh_expires_in(long refresh_expires_in) {
			this.refresh_expires_in = refresh_expires_in;
		}
		public String getMobile_number() {
			return mobile_number;
		}
		public void setMobile_number(String mobile_number) {
			this.mobile_number = mobile_number;
		}
		public String getNew_account() {
			return new_account;
		}
		public void setNew_account(String new_account) {
			this.new_account = new_account;
		}
	
}
