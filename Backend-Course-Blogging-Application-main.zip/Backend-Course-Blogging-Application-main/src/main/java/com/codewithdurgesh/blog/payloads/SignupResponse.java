package com.codewithdurgesh.blog.payloads;

public class SignupResponse {
	
	

	public SignupResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public SignupResponse(String message, String signupToken) {
		super();
		this.message = message;
		this.signupToken = signupToken;
	}


	private String message;
    private String signupToken;
    
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getSignupToken() {
		return signupToken;
	}
	public void setSignupToken(String signupToken) {
		this.signupToken = signupToken;
	}
    
    
}
